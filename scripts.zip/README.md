# Scripts

Rebuild / fetch / ETL helpers. **Never commit `.env`.** Copy repo-root `.env.example` → `.env` and set `OPENALEX_API_KEY` only on your machine.

## Critical warnings

| Script | Status |
|--------|--------|
| **`../scrape_openalex_data.py`** (repo root) | **NON-CANONICAL.** Uses ASJC-like `primary_topic.subfield.id` filters. Quantum=`2500` is **Materials Science** (forbidden for live G3). Refuses / must not rebuild `viz3_data.js`. |
| **`CS661_Dataset/raw_vault/04_openalex/fetch_topics_full.py`** | **Canonical** G3 river fetch (OpenAlex **concepts**). |
| **`dashboard/_river_to_pool_rebuild.py`** | Canonical river → G1/G2/G3/(related) pool rebuild. |

## G4 expand

```powershell
python scripts/expand_g4_openalex.py
python scripts/expand_g4_openalex.py --max-new 15
# region balance / Europe lock options — see dashboard/docs/G4_REGION_BALANCE.md
```

- Cache/resume: `CS661_Dataset/raw_vault/g4_expand_cache.json`
- Writes collaboration premium river + feeds `dashboard/viz4_data.js` (live **73** countries)
- Status: `dashboard/docs/G4_EXPAND_STATUS.md`

Related: `rebuild_g2_g4_project_pool.py`, `_g4_probe_*.py`, `_verify_g2_g4.py`, `_verify_viz4_n.py`.

## G3 topics

```powershell
python CS661_Dataset/raw_vault/04_openalex/fetch_topics_full.py
python dashboard/_river_to_pool_rebuild.py
```

L2 demo pool only (does not write live `viz3_data.js`):

```powershell
python demos/g3-l2-broader/_rebuild_l2_viz3.py
```

## India network (G5)

Pipeline under `scripts/india_network/` (numbered stages `00_`…`10_`, plus acquisition/).

```powershell
pip install -r requirements-india-network.txt
# .env with OPENALEX_API_KEY for fetch stages
python scripts/india_network/regenerate_india_network_data_js.py
```

Heavy OpenAlex works cache lives under `data/cache/` (often **omitted** from zips — multi‑GB). Ship `dashboard/data/india_network/*.json` for viewing G5 without re-fetch.

## Quality shift (G2 density helpers)

`scripts/quality_shift/` — download/normalize/ridgeline density export. Requirements: `quality_shift/requirements-quality-shift.txt`.

## Other

| Script | Role |
|--------|------|
| `convert_lecture_pdfs.py` | Lecture PDF conversion (optional) |
| `_qa_g2_g4_playwright.py` | Playwright QA (needs browser deps) |
| `sync_hierarchy_app.ps1` | Hierarchy app sync (optional legacy) |

## Dashboard-side rebuild scripts (not under scripts/)

| Path | Role |
|------|------|
| `dashboard/_river_to_pool_rebuild.py` | Main pool rebuild |
| `dashboard/_build_gerd_hierarchy.py` | GERD hierarchical river |
| `dashboard/_regen_viz1_umap.py` | UMAP x,y regen for G1 |
| `dashboard/_verify_river_fix.py` | Verify river fix |
| `dashboard/_audit_*.py` | Audits (G2/G3/GERD) |
