import pandas as pd
from pathlib import Path
from config import PROCESSED_DIR
from openalex_http import openalex_get
import sys

def flatten_institution(row: dict) -> dict:
    geo = row.get("geo") or {}
    ror = row.get("ror")
    return {
        "openalex_id": (row.get("id") or "").rsplit("/", 1)[-1],
        "display_name": row.get("display_name"),
        "ror_id": ror.rsplit("/", 1)[-1] if ror else None,
        "works_count": row.get("works_count") or 0,
        "cited_by_count": row.get("cited_by_count") or 0,
        "city": geo.get("city"),
        "region": geo.get("region"),
        "latitude": geo.get("latitude"),
        "longitude": geo.get("longitude"),
        "type": row.get("type"),
    }

def main():
    oa_path = PROCESSED_DIR / "openalex_institutions.parquet"
    if not oa_path.exists():
        print("Parquet file not found")
        sys.exit(1)
        
    df = pd.read_parquet(oa_path)
    
    ids_to_fetch = ["I24676775", "I4210113248"]
    
    for openalex_id in ids_to_fetch:
        print(f"Fetching {openalex_id}...")
        resp = openalex_get(f"institutions/{openalex_id}")
        resp.raise_for_status()
        inst_data = resp.json()
        flat_inst = flatten_institution(inst_data)
        
        # Check if exists
        idx = df[df['openalex_id'] == openalex_id].index
        if len(idx) > 0:
            for k, v in flat_inst.items():
                df.loc[idx, k] = v
        else:
            # Append as new row using pd.concat
            df = pd.concat([df, pd.DataFrame([flat_inst])], ignore_index=True)
            
    df.to_parquet(oa_path, index=False)
    print("Updated openalex_institutions.parquet")

if __name__ == "__main__":
    main()
