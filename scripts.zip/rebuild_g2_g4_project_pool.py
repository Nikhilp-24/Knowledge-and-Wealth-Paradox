"""Rebuild CS661 Project G2/G4 pool taps from river CSVs (honest uncapped / 20-country panel)."""
from __future__ import annotations

import csv
import json
import shutil
from collections import defaultdict
from pathlib import Path

ROOT = Path(r"C:\Users\brata\Downloads\CS661")
PROJECT = ROOT / "CS661 Project"
RIVER_TEAM = ROOT / "CS661_Dataset" / "raw_vault" / "READY_FOR_TEAM"
RIVER_Q = ROOT / "CS661_Dataset" / "raw_vault" / "03_scimago_journal_quartiles" / "q1_q4_country_year.csv"
PREMIUM = ROOT / "CS661_Dataset" / "collaboration_premium.csv"
PROOF: dict = {}

# Prefer READY_FOR_TEAM copies when present
q_path = RIVER_TEAM / "q1_q4_country_year.csv"
if not q_path.exists():
    q_path = RIVER_Q
prem_path = RIVER_TEAM / "collaboration_premium.csv"
if not prem_path.exists():
    prem_path = PREMIUM

# ---------------------------------------------------------------------------
# G2 — uncapped publisher-country Q1/Q4
# ---------------------------------------------------------------------------
src_g2 = PROJECT / "ridgeline_data.js"
bak_g2 = PROJECT / "ridgeline_data_BEFORE_POOLFIX.js"
if not bak_g2.exists():
    shutil.copy2(src_g2, bak_g2)
    PROOF["G2_backup"] = bak_g2.name
else:
    PROOF["G2_backup"] = f"kept {bak_g2.name}"

river_q = list(csv.DictReader(q_path.open(encoding="utf-8")))
by_year: dict[str, list] = defaultdict(list)
for r in river_q:
    year = str(int(r["year"]))
    by_year[year].append(
        {
            "country": r["country"],
            "region": r["region"],
            "q1": int(float(r["q1"])),
            "q4": int(float(r["q4"])),
            "total": int(float(r["total"])),
            "ratio": float(r["ratio"]),  # uncapped
        }
    )
out_g2 = {y: sorted(by_year[y], key=lambda x: x["country"]) for y in sorted(by_year.keys(), key=int)}
src_g2.write_text(
    "// G2 pool: SCImago journalrank publisher-Country × Best Quartile (uncapped ratio)\n"
    "// Source: q1_q4_country_year.csv — NOT author-affiliation counts\n"
    "const REAL_RIDGELINE_DATA = "
    + json.dumps(out_g2, separators=(",", ":"))
    + ";\n",
    encoding="utf-8",
)

def load_ridgeline(path: Path):
    text = path.read_text(encoding="utf-8")
    i, j = text.find("{"), text.rfind("}")
    return json.loads(text[i : j + 1])

pool_g2 = load_ridgeline(src_g2)
river_2022 = {r["country"]: r for r in river_q if str(int(r["year"])) == "2022"}
pool_2022 = {r["country"]: r for r in pool_g2["2022"]}
anchors = ["United States", "China", "India", "United Kingdom"]
g2_checks = []
for c in anchors:
    p, rv = pool_2022[c], river_2022[c]
    ok = (
        int(p["q1"]) == int(float(rv["q1"]))
        and int(p["q4"]) == int(float(rv["q4"]))
        and abs(float(p["ratio"]) - float(rv["ratio"])) < 1e-9
    )
    g2_checks.append({"country": c, "pool_ratio": p["ratio"], "river_ratio": float(rv["ratio"]), "exact": ok})
assert all(x["exact"] for x in g2_checks), g2_checks
PROOF["G2"] = {
    "years": f"{min(out_g2)}-{max(out_g2)}",
    "country_years": sum(len(v) for v in out_g2.values()),
    "anchors_2022": g2_checks,
    "bytes": src_g2.stat().st_size,
}
print("G2 OK", PROOF["G2"]["years"], "USA ratio", pool_2022["United States"]["ratio"])

# ---------------------------------------------------------------------------
# G4 — full year panel from collaboration_premium (20 countries × years)
# ---------------------------------------------------------------------------
src_g4 = PROJECT / "viz4_data.js"
bak_g4 = PROJECT / "viz4_data_BEFORE_POOLFIX.js"
if not bak_g4.exists():
    shutil.copy2(src_g4, bak_g4)
    PROOF["G4_backup"] = bak_g4.name
else:
    PROOF["G4_backup"] = f"kept {bak_g4.name}"

old_text = bak_g4.read_text(encoding="utf-8")
i, j = old_text.find("["), old_text.rfind("]")
old_v4 = json.loads(old_text[i : j + 1]) if i >= 0 and j > i else []
region_by_name = {r["name"]: r["region"] for r in old_v4 if "name" in r}

SIMPLE = {
    "AU": "Oceania",
    "BR": "Latin America",
    "CA": "North America",
    "CH": "Europe",
    "CN": "East Asia & Pacific",
    "DE": "Europe",
    "ES": "Europe",
    "FR": "Europe",
    "GB": "Europe",
    "IN": "South Asia",
    "IR": "Middle East & Africa",
    "IT": "Europe",
    "JP": "East Asia & Pacific",
    "KR": "East Asia & Pacific",
    "NL": "Europe",
    "PL": "Europe",
    "RU": "Europe",
    "SE": "Europe",
    "TR": "Middle East & Africa",
    "US": "North America",
}

NAME_FIX = {
    "Russian Federation": "Russia",
    "Korea, Republic of": "South Korea",
    "Iran, Islamic Republic of": "Iran",
    "United States of America": "United States",
    "United Kingdom of Great Britain and Northern Ireland": "United Kingdom",
}

prem = list(csv.DictReader(prem_path.open(encoding="utf-8")))
by_y: dict[str, list] = defaultdict(list)
for r in prem:
    year = str(int(r["Year"]))
    raw_name = r["Country_Name"]
    display = NAME_FIX.get(raw_name, raw_name)
    if display == "Korea":
        display = "South Korea"
    # Common premium names
    if raw_name in ("Korea, Rep.", "Republic of Korea", "South Korea"):
        display = "South Korea"
    if raw_name in ("Iran", "Iran (Islamic Republic of)"):
        display = "Iran"
    region = region_by_name.get(display) or SIMPLE.get(r["Country_Code"], "Unknown")
    # Prefer SIMPLE continental labels matching Project controls
    region = SIMPLE.get(r["Country_Code"], region)
    by_y[year].append(
        {
            "name": display,
            "region": region,
            "iso2": r["Country_Code"],
            "domestic": round(float(r["Domestic_Avg_Citations"]), 1),
            "international": round(float(r["International_Avg_Citations"]), 1),
            "gain": round(float(r["Citation_Gain"]), 1),
            "domestic_papers": int(float(r["Domestic_Papers"])),
            "international_papers": int(float(r["International_Papers"])),
        }
    )

for y in by_y:
    by_y[y] = sorted(by_y[y], key=lambda x: x["name"])

years = sorted(by_y.keys(), key=int)
default_year = years[-1]
# Back-compat flat array = default year (legacy readers)
flat = by_y[default_year]

header = (
    f"// G4 pool: OpenAlex collaboration premium — {len(flat)} countries × years {years[0]}–{years[-1]}\n"
    f"// Source: collaboration_premium.csv (domestic = countries_distinct_count:1; intl = >1)\n"
    f"// Default cross-section year: {default_year}. Prefer VIZ4_BY_YEAR[year] in TAP.\n"
)
body = (
    header
    + f"const VIZ4_YEARS = {json.dumps([int(y) for y in years])};\n"
    + f"const VIZ4_DEFAULT_YEAR = {default_year};\n"
    + f"const VIZ4_BY_YEAR = {json.dumps(dict(by_y), indent=2)};\n"
    + f"const VIZ4_DATA = VIZ4_BY_YEAR[String(VIZ4_DEFAULT_YEAR)];\n"
)
src_g4.write_text(body, encoding="utf-8")
PROOF["G4"] = {
    "years": f"{years[0]}-{years[-1]}",
    "countries_per_year": {y: len(by_y[y]) for y in years},
    "default_year": int(default_year),
    "bytes": src_g4.stat().st_size,
    "usa_2024": next(x for x in by_y[default_year] if x["name"] == "United States"),
}
print("G4 OK", PROOF["G4"]["years"], "countries", len(flat), "USA", PROOF["G4"]["usa_2024"])

proof_path = ROOT / "docs" / "_g2_g4_pool_rebuild_proof.json"
proof_path.parent.mkdir(exist_ok=True)
proof_path.write_text(json.dumps(PROOF, indent=2), encoding="utf-8")
print("Wrote", proof_path)
