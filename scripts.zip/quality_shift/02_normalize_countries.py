import json
import pandas as pd
import pycountry
from pathlib import Path
import sys
import glob

_NORM_CACHE = {}
def normalize_country(name):
    if name in _NORM_CACHE:
        return _NORM_CACHE[name]
        
    # Some common mapping overrides for SCImago
    overrides = {
        "United States": "USA",
        "United Kingdom": "GBR",
        "Russian Federation": "RUS",
        "South Korea": "KOR",
        "Iran": "IRN",
        "Syrian Arab Republic": "SYR"
    }
    if name in overrides:
        _NORM_CACHE[name] = overrides[name]
        return overrides[name]
        
    try:
        res = pycountry.countries.search_fuzzy(name)
        _NORM_CACHE[name] = res[0].alpha_3
        return _NORM_CACHE[name]
    except:
        _NORM_CACHE[name] = None
        return None

def main():
    print("Running 02_normalize_countries.py")
    raw_dir = Path("data/raw/scimago")
    out_dir = Path("data/processed/quality_shift")
    out_dir.mkdir(parents=True, exist_ok=True)
    
    csv_files = glob.glob(str(raw_dir / "journalrank_*.csv"))
    if not csv_files:
        print("ERROR: No journalrank CSVs found. Please run script 01 or download manually.")
        sys.exit(1)
        
    all_data = []
    
    # We expect SCImago Journal Rank to contain 'Country', 'SJR Best Quartile', 'Total Docs. (year)'
    # Or if the user downloaded Country Rank, it won't have Q1/Q4! 
    # Let's handle Journal Rank:
    for fpath in csv_files:
        year_str = Path(fpath).stem.split("_")[-1]
        try:
            year = int(year_str)
        except:
            continue
            
        print(f"-> Processing year {year}")
        df = pd.read_csv(fpath, sep=";", encoding="cp1252")
        
        # Ensure we have required columns
        # Depending on SCImago export, columns can be 'Country', 'SJR Best Quartile', 'Total Docs. (year)'
        # or 'Total Docs. (2020)'
        doc_col = [c for c in df.columns if 'Total Docs.' in c]
        if not doc_col:
            doc_col = ['Docs'] # fallback
        else:
            doc_col = doc_col[0]
            
        if 'Country' not in df.columns or 'SJR Best Quartile' not in df.columns:
            print(f"Skipping {year}: missing Country or SJR Best Quartile columns.")
            continue
            
        # Group by Country and Quartile
        # Quartile values: Q1, Q2, Q3, Q4, - (unassigned)
        agg = df.groupby(['Country', 'SJR Best Quartile'])[doc_col].sum().reset_index()
        
        # Pivot to get Q1..Q4 as columns
        pivot = agg.pivot(index='Country', columns='SJR Best Quartile', values=doc_col).fillna(0)
        
        # Ensure all Q columns exist
        for q in ['Q1', 'Q2', 'Q3', 'Q4']:
            if q not in pivot.columns:
                pivot[q] = 0
                
        pivot['Year'] = year
        pivot = pivot.reset_index()
        all_data.append(pivot)
        
    if not all_data:
        print("ERROR: No data processed.")
        sys.exit(1)
        
    combined = pd.concat(all_data, ignore_index=True)
    
    print("Normalizing country codes...")
    combined['ISO3'] = combined['Country'].apply(normalize_country)
    
    # F4: Drop rows with missing year/country
    combined = combined.dropna(subset=['ISO3', 'Year'])
    
    # F1: Valid ISO country (already handled by normalization keeping valid ones)
    
    out_file = out_dir / "country_year_metrics.parquet"
    combined.to_parquet(out_file)
    print(f"Wrote {len(combined)} rows to {out_file}")

if __name__ == "__main__":
    main()
