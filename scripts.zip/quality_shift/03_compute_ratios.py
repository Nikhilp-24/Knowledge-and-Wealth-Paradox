import pandas as pd
from pathlib import Path
import sys

def main():
    print("Running 03_compute_ratios.py")
    
    in_file = Path("data/processed/quality_shift/country_year_metrics.parquet")
    if not in_file.exists():
        print("ERROR: input parquet not found")
        sys.exit(1)
        
    df = pd.read_parquet(in_file)
    
    # Calculate Total Documents
    df['Documents'] = df[['Q1', 'Q2', 'Q3', 'Q4']].sum(axis=1)
    
    # F2: Documents >= MIN_DOCS
    MIN_DOCS = 100
    df = df[df['Documents'] >= MIN_DOCS].copy()
    
    # F3: %Q1..%Q4 sum calculation
    # Since we computed from raw document counts in step 2, we can just use those absolute numbers
    # ratio = q1_docs / max(q4_docs, 1)
    df['q1_docs'] = df['Q1']
    df['q4_docs'] = df['Q4']
    
    # Cap zero denominator to avoid Inf
    df['ratio'] = df['q1_docs'] / df['q4_docs'].clip(lower=1)
    
    out_file = Path("data/processed/quality_shift/country_ratios.parquet")
    df.to_parquet(out_file)
    
    print(f"Computed ratios. Wrote {len(df)} rows to {out_file}")

if __name__ == "__main__":
    main()
