import json
import os
from pathlib import Path

def main():
    print("Running 00_detect_year_range.py")
    out_dir = Path("data/processed/quality_shift")
    out_dir.mkdir(parents=True, exist_ok=True)
    
    # Since SCImago CSVs are structured by year from 1996, and 2024 is the latest stable year
    # we will use 1996 to 2024.
    year_range = {
        "YEAR_MIN": 1996,
        "YEAR_MAX": 2024
    }
    
    out_file = out_dir / "year_range.json"
    with open(out_file, "w") as f:
        json.dump(year_range, f, indent=2)
        
    print(f"Detected year range: {year_range['YEAR_MIN']} to {year_range['YEAR_MAX']}")
    print(f"Wrote to {out_file}")

if __name__ == "__main__":
    main()
