import pandas as pd
from pathlib import Path
import json
import sys

def main():
    print("Running 05_export_panel_json.py")
    in_file = Path("data/processed/quality_shift/country_ratios.parquet")
    if not in_file.exists():
        print("ERROR: Ratios not found")
        sys.exit(1)
        
    df = pd.read_parquet(in_file)
    
    # We want: { ISO3: [ {year, q1, q4, ratio, docs}, ... ] }
    # Or just an array of objects which can be easily indexed by crossfilter/frontend
    
    records = df[['ISO3', 'Year', 'Q1', 'Q4', 'Documents', 'ratio']].rename(columns={
        'Q1': 'q1',
        'Q4': 'q4',
        'Documents': 'total_docs',
        'Year': 'year',
        'ISO3': 'iso3'
    }).to_dict(orient='records')
    
    # Group by iso3 for easier lookup in frontend
    panel_data = {}
    for r in records:
        iso3 = r['iso3']
        if iso3 not in panel_data:
            panel_data[iso3] = {}
            
        panel_data[iso3][str(r['year'])] = {
            'q1': r['q1'],
            'q4': r['q4'],
            'ratio': round(r['ratio'], 3),
            'total_docs': r['total_docs']
        }
        
    out_dir = Path("data/processed/quality_shift")
    out_file = out_dir / "panel_data.json"
    
    with open(out_file, "w") as f:
        json.dump(panel_data, f, indent=2)
        
    print(f"Exported panel data for {len(panel_data)} countries to {out_file}")

if __name__ == "__main__":
    main()
