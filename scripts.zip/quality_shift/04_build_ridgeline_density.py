import pandas as pd
import numpy as np
from scipy.stats import gaussian_kde
from pathlib import Path
import json
import sys

def main():
    print("Running 04_build_ridgeline_density.py")
    in_file = Path("data/processed/quality_shift/country_ratios.parquet")
    if not in_file.exists():
        print("ERROR: Ratios not found")
        sys.exit(1)
        
    df = pd.read_parquet(in_file)
    
    # We will compute KDE for each year
    years = sorted(df['Year'].unique())
    
    # Define X domain for KDE
    X_MIN = 0.0
    X_MAX = 5.0
    NUM_POINTS = 50
    x_eval = np.linspace(X_MIN, X_MAX, NUM_POINTS)
    
    densities = []
    
    for year in years:
        year_df = df[df['Year'] == year]
        ratios = year_df['ratio'].dropna().values
        
        if len(ratios) < 5:
            # Not enough data points
            continue
            
        kde = gaussian_kde(ratios, bw_method='scott')
        y_eval = kde.evaluate(x_eval)
        
        densities.append({
            "year": int(year),
            "points": [{"x": round(float(x), 3), "y": round(float(y), 4)} for x, y in zip(x_eval, y_eval)]
        })
        
    out_dir = Path("data/processed/quality_shift")
    out_file = out_dir / "ridgeline_density.json"
    
    with open(out_file, "w") as f:
        json.dump(densities, f, indent=2)
        
    print(f"Generated KDE for {len(densities)} years. Wrote to {out_file}")

if __name__ == "__main__":
    main()
